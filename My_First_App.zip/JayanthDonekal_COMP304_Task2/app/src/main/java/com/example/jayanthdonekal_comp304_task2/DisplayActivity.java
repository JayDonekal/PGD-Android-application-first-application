package com.example.jayanthdonekal_comp304_task2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {
    public static final String EXTRA_TEXT1 = "Name";
    public static final String EXTRA_TEXT2 = "Qualification";
    public static final String EXTRA_TEXT3 = "DreamJob";
    public static final String EXTRA_TEXT4 = "SpecializedField";
    @Override


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        TextView textView5 = findViewById(R.id.textView5);
        TextView textView6 = findViewById(R.id.textView6);
        TextView textView7 = findViewById(R.id.textView7);
        TextView textView8 = findViewById(R.id.textView8);

        Intent intent = getIntent();

        String text1 = intent.getStringExtra(EXTRA_TEXT1);
        String text2 = intent.getStringExtra(EXTRA_TEXT2);
        String text3 = intent.getStringExtra(EXTRA_TEXT3);
        String text4 = intent.getStringExtra(EXTRA_TEXT4);
        textView5.setText(text1);
        textView6.setText(text2);
        textView7.setText(text3);
        textView8.setText(text4);



    }
}